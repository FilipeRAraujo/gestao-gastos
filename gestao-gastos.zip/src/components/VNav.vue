<template>
	<div class="v-nav">
		<div class="v-nav-itens">
			<div>Item 1</div>
			<div>Item 2</div>
			<div>Item 3</div>
		</div>
	</div>
</template>
<style>
	.v-nav {
		display: flex;
	}

	.v-nav-itens {
		display: flex;
	}
</style>
<script>

export default {
    name: 'VNav',
}
</script>
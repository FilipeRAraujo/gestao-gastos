<template>
	<div class="home">
		<VNav />
		<div>
			<h1>Home aqui</h1>
		</div>
	</div>
</template>
<script>
import VNav from '@/components/VNav.vue'

export default {
    name: 'HomeView',
    components: {
        VNav
    }
}
</script>
module.exports = class MessagePayloadResponse {
    message;

    constructor(message) {
        this.message = message;
    }
}
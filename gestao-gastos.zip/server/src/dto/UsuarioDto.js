module.exports = class UsuarioDto {
    id;
    nome;
    email;
    senha;
    salt;
}
const http = require('http'),
    express = require('express')
    cors = require('cors'),
    app = express();

const bodyParser = require('body-parser');

app.use(cors());
app.use(bodyParser.json());

const AutenticadorAction = require('./src/action/AutenticadorAction');

app.post('/login', new AutenticadorAction().logar);
app.post('/register', new AutenticadorAction().registrar);

app.get('/aboutMe', (req, resp, next) => {
    resp.send({ me: 'Analista de Sistemas Java' });
})

app.listen(8000);